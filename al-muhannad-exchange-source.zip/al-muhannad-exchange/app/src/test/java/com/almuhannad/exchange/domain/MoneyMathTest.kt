package com.almuhannad.exchange.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class MoneyMathTest {
    @Test fun multipliesUsingScaledRateWithoutFloatingPoint() {
        assertEquals(150_000L, MoneyMath.multiplyMinorUnits(100_000L, 1_500_000L))
    }

    @Test fun rejectsNegativeAmounts() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyMath.multiplyMinorUnits(-1, 1_000_000)
        }
    }

    @Test fun preventsSpendingMoreThanBalance() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyMath.subtractNonNegative(500, 501)
        }
    }

    @Test fun subtractsValidAmount() {
        assertEquals(250L, MoneyMath.subtractNonNegative(500, 250))
    }
}
