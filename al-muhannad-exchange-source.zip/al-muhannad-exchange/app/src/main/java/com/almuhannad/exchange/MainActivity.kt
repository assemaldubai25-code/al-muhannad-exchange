package com.almuhannad.exchange

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.almuhannad.exchange.data.CurrencyEntity
import com.almuhannad.exchange.data.ExchangeDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat

private val Navy = Color(0xFF101D43)
private val NavyCard = Color(0xFF1B2C55)
private val Gold = Color(0xFFD5B15E)
private val Cream = Color(0xFFF6F4EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = ExchangeDatabase.getInstance(applicationContext).exchangeDao()
        lifecycleScope.launch(Dispatchers.IO) { dao.addOpeningCurrencyIfMissing() }
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Cream)) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
                        Dashboard(dao = dao)
                    }
                }
            }
        }
    }
}

@Composable
private fun Dashboard(dao: com.almuhannad.exchange.data.ExchangeDao) {
    val currencies by dao.observeCurrencies().collectAsState(initial = emptyList())
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(56.dp).background(Gold, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Navy, modifier = Modifier.size(30.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("المهند", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("للصرافة والتحويلات", color = Color.White, fontSize = 15.sp)
                        }
                    }
                    Divider(color = Gold.copy(alpha = .65f))
                    Text("لوحة الإدارة الرئيسية", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("نسخة أولية • تخزين محلي دون إنترنت", color = Color(0xFFD9DEEA), fontSize = 12.sp)
                }
            }
        }
        item { SectionTitle("العملات المسجلة") }
        if (currencies.isEmpty()) {
            item { Text("جارٍ تجهيز قاعدة البيانات المحلية…", color = Navy, modifier = Modifier.padding(8.dp)) }
        } else {
            items(currencies, key = { it.id }) { currency -> CurrencyCard(currency) }
        }
        item { SectionTitle("الخدمات الرئيسية") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("الحوالات", "إنشاء حوالة وتتبع حالتها", Icons.Default.Send)
                FeatureCard("الصندوق والحركات", "سند قبض وصرف وسجل مالي", Icons.Default.AccountBalanceWallet)
                FeatureCard("أسعار الصرف", "أسعار شراء وبيع العملات", Icons.Default.CurrencyExchange)
                FeatureCard("العملاء", "ملفات العملاء وسجل التعاملات", Icons.Default.People)
                FeatureCard("التقارير", "الحركة اليومية والأرصدة", Icons.Default.Assessment)
            }
        }
        item {
            Text(
                "تنبيه: هذه نسخة تأسيسية. لا تستخدمها لتسجيل أموال حقيقية قبل استكمال شاشات العمليات، التحقق المحاسبي، النسخ الاحتياطي واختبارات القبول.",
                color = Color(0xFF7A4B00), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun CurrencyCard(currency: CurrencyEntity) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Gold.copy(alpha = .20f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = Navy)
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(currency.nameAr, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(currency.code, color = Color.Gray, fontSize = 12.sp)
            }
            Text("مضافة", color = Color(0xFF39734D), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = NavyCard), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Color(0xFFD9DEEA), fontSize = 12.sp)
            }
        }
    }
}
