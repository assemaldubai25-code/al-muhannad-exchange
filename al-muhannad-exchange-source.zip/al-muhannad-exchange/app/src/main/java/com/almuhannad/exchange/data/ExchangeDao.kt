package com.almuhannad.exchange.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ExchangeDao {
    @Query("SELECT * FROM currencies WHERE isActive = 1 ORDER BY code")
    fun observeCurrencies(): Flow<List<CurrencyEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCurrency(currency: CurrencyEntity): Long

    @Query("SELECT * FROM customers ORDER BY fullName COLLATE NOCASE")
    fun observeCustomers(): Flow<List<CustomerEntity>>

    @Insert
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Query("SELECT * FROM ledger_entries ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecentLedger(limit: Int = 50): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLedgerEntry(entry: LedgerEntryEntity): Long

    @Query("SELECT COALESCE(SUM(CASE WHEN direction = 'IN' THEN amountMinor ELSE -amountMinor END), 0) FROM ledger_entries WHERE currencyCode = :code")
    fun observeBalanceMinor(code: String): Flow<Long>

    @Query("SELECT * FROM transfers ORDER BY createdAt DESC")
    fun observeTransfers(): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE reference = :reference LIMIT 1")
    suspend fun findTransfer(reference: String): TransferEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTransfer(transfer: TransferEntity): Long

    @Query("UPDATE transfers SET status = 'PAID', paidAt = :paidAt WHERE id = :id AND status = 'PENDING'")
    suspend fun markTransferPaid(id: Long, paidAt: Long = System.currentTimeMillis()): Int

    @Query("SELECT * FROM exchange_rates ORDER BY fromCode, toCode")
    fun observeRates(): Flow<List<ExchangeRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveRate(rate: ExchangeRateEntity)

    @Transaction
    suspend fun addOpeningCurrencyIfMissing() {
        listOf(
            CurrencyEntity(code = "YER", nameAr = "ريال يمني", minorUnitDigits = 0),
            CurrencyEntity(code = "SAR", nameAr = "ريال سعودي", minorUnitDigits = 2),
            CurrencyEntity(code = "USD", nameAr = "دولار أمريكي", minorUnitDigits = 2)
        ).forEach { currency ->
            try { insertCurrency(currency) } catch (_: android.database.sqlite.SQLiteConstraintException) { /* already seeded */ }
        }
    }
}
