package com.almuhannad.exchange.domain

/** Monetary values are stored as integer minor units; never use Float/Double for money. */
object MoneyMath {
    fun multiplyMinorUnits(amountMinor: Long, rateScaled: Long, rateScale: Long = 1_000_000L): Long {
        require(amountMinor >= 0) { "المبلغ لا يمكن أن يكون سالباً" }
        require(rateScaled >= 0) { "سعر الصرف لا يمكن أن يكون سالباً" }
        require(rateScale > 0) { "مقياس السعر غير صالح" }
        // BigInteger avoids overflow in intermediate multiplication; integer division rounds down.
        return java.math.BigInteger.valueOf(amountMinor)
            .multiply(java.math.BigInteger.valueOf(rateScaled))
            .divide(java.math.BigInteger.valueOf(rateScale))
            .longValueExact()
    }

    fun add(a: Long, b: Long): Long = Math.addExact(a, b)
    fun subtractNonNegative(balance: Long, amount: Long): Long {
        require(balance >= 0 && amount >= 0) { "المبلغ أو الرصيد غير صالح" }
        require(amount <= balance) { "الرصيد غير كافٍ" }
        return balance - amount
    }
}
