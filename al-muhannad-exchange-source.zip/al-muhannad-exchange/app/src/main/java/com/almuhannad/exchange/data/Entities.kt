package com.almuhannad.exchange.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "currencies", indices = [Index(value = ["code"], unique = true)])
data class CurrencyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val nameAr: String,
    val minorUnitDigits: Int = 2,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers", indices = [Index("phone")])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** Append-only financial journal. Reversals should be new entries, not edits/deletes. */
@Entity(tableName = "ledger_entries", indices = [Index("createdAt"), Index("reference")])
data class LedgerEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reference: String,
    val currencyCode: String,
    val direction: String, // IN or OUT
    val amountMinor: Long,
    val category: String,
    val description: String = "",
    val customerId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = "المدير",
    val reversedEntryId: Long? = null
)

@Entity(tableName = "transfers", indices = [Index(value = ["reference"], unique = true), Index("status"), Index("createdAt")])
data class TransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reference: String,
    val senderName: String,
    val senderPhone: String = "",
    val receiverName: String,
    val receiverPhone: String = "",
    val destination: String = "",
    val currencyCode: String,
    val amountMinor: Long,
    val feeMinor: Long = 0,
    val status: String = "PENDING", // PENDING, PAID, CANCELLED
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val paidAt: Long? = null
)

@Entity(tableName = "exchange_rates", indices = [Index(value = ["fromCode", "toCode"], unique = true)])
data class ExchangeRateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromCode: String,
    val toCode: String,
    val buyRateScaled: Long,
    val sellRateScaled: Long,
    val updatedAt: Long = System.currentTimeMillis()
)
