package com.almuhannad.exchange.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import java.util.concurrent.Executors

@Database(
    entities = [CurrencyEntity::class, CustomerEntity::class, LedgerEntryEntity::class, TransferEntity::class, ExchangeRateEntity::class],
    version = 1,
    exportSchema = true
)
abstract class ExchangeDatabase : RoomDatabase() {
    abstract fun exchangeDao(): ExchangeDao

    companion object {
        @Volatile private var INSTANCE: ExchangeDatabase? = null

        fun getInstance(context: Context): ExchangeDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ExchangeDatabase::class.java,
                "almuhannad_exchange.db"
            ).addCallback(object : Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    // Seed is run after database creation by MainActivity on IO dispatcher.
                }
            }).build().also { INSTANCE = it }
        }
    }
}
